package Controller;

import Entidades.Usuario;
import Persistencia.PerfilDAO;
import Persistencia.UsuarioDAO;
import javax.swing.JOptionPane;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Rafael Rosa
 */


public class LoginController {

    private Usuario usuario;
    private UsuarioDAO daoUsuario;

    private StringBuilder mensagemDeErro;
    private boolean camposValidos;

    // Objetivo do metodo setUp manipular o usuário
    private void setUp() {

        usuario = new Usuario();

        daoUsuario = new UsuarioDAO();

        mensagemDeErro = new StringBuilder();

        camposValidos = false;

    }

    // Metodo para receber as duas String da tela login ( User Name e Senha )
    public Usuario realizarLogin(String username, String senha) {

        // Invocar o metodo setUp ( chamar o método)
        setUp();
        usuario.setUserName(username);
        usuario.setSenha(senha);

        if (validarCampos(usuario)) {

            // Verificar se o usuário e senha exitem no banco
            for (Usuario usuarioDoBD : daoUsuario.listarTodos()) {

                if (usuario.getUserName().equals(usuarioDoBD.getUserName())) {

                    if (usuario.getSenha().equals(usuarioDoBD.getSenha())) {

                        // JOoptionPane sçao metodos státicos para criar caixas de diálogos simples e objetivas.
                        JOptionPane.showMessageDialog(null, "Login realizado com sucesso");
                    }

                } else {
                    // JOoptionPane sçao metodos státicos para criar caixas de diálogos simples e objetivas.
                    JOptionPane.showMessageDialog(null, "Login Erro");
                }
            }
        }

        return usuario;
    }

    // Método para validar os campos da tela login
    // Método boolean irá retorna false
    public boolean validarCampos(Usuario usuario) {

        // Verificar se o usuário preencheu o campos nome
        if (usuario.getUserName() == null || usuario.getUserName().equals("") || usuario.getUserName().isEmpty()) {

            mensagemDeErro.append("Favor preencher o campo NOME");

            camposValidos = false;
        }

        // Verificar se o usuário preencheu o campos Senha
        if ((usuario.getSenha().isEmpty() || usuario.getSenha() == null) || usuario.getSenha().equals("")) {
            mensagemDeErro.append("Favor preencher o campo SENHA");
            camposValidos = false;
        } else {
        }

        camposValidos = true;
        return camposValidos;
    }

}
