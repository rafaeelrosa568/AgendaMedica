package Entidades;

import lombok.*;

/**
 *
 * @author Rafael Rosa
 */

public class Bairro {

    private int identificador;
    private String descricao;
    private Cidade cidade;

}
