package Entidades;

import lombok.*;

/**
 *
 * @author Rafael Rosa
 */

public class Cargo {

    private int identificador;
    private String descricao;
    private boolean ativo;

    @Override
    public String toString() {
        return this.descricao;
    }

}
