package Entidades;

import lombok.*;

/**
 *
 * @author Rafael Rosa
 */


public class Cep {

    private Integer cep;
    private Logradouro logradouro;

}
