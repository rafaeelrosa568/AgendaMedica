package Entidades;

import lombok.*;


public class Perfil {

    private int identificador;
    private String descricao;

    @Override
    public String toString() {
        return this.descricao;
    }

}
