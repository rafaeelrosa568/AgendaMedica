package Entidades;

import lombok.*;

/**
 *
 * @author Rafael Rosa
 */

public class TipoEndereco {

    private int identificador;
    private String descricao;

}
