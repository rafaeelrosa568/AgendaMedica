package Entidades;

import lombok.*;

/**
 *
 * @author Rafael Rosa
 */

public class TipoTelefone {

    private int identificador;
    private String descricao;

}
