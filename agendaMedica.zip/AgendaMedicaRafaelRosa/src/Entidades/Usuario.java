package Entidades;

import java.util.Date;
import lombok.*;


public class Usuario extends Pessoa {

    private String userName;
    private String senha;
    private boolean ativo;
    private Perfil perfil;
    private Date dataCadastro;

    @Override
    public String toString() {
        return getNome();
    }

    public void setUserName(String username) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setSenha(String senha) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Object getUserName() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Object getSenha() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
